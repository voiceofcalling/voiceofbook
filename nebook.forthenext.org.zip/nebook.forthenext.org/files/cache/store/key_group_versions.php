<?php
if(!defined('__XE__')) { exit(); }
return 'a:2:{s:15:"site_and_module";i:219;s:6:"member";i:1;}';