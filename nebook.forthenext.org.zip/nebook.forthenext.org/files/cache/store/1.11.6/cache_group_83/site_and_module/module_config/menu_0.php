<?php
if(!defined('__XE__')) { exit(); }
return 'O:8:"stdClass":1:{s:17:"unlinked_menu_srl";i:148;}';