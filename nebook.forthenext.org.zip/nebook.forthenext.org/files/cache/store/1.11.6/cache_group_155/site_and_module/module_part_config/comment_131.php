<?php
if(!defined('__XE__')) { exit(); }
return 'O:8:"stdClass":4:{s:13:"comment_count";i:50;s:11:"use_vote_up";s:1:"Y";s:13:"use_vote_down";s:1:"Y";s:22:"use_comment_validation";s:1:"Y";}';