<?php
if(!defined('__XE__')) { exit(); }
return 'a:1:{i:0;a:3:{s:8:"filepath";s:66:"./files/attach/images/131/141/624c31acd1d992a9fcffc068c2289cab.jpg";s:5:"width";i:200;s:6:"height";i:158;}}';