<?php
if(!defined('__XE__')) { exit(); }
return 'a:1:{i:0;a:3:{s:8:"filepath";s:66:"./files/attach/images/146/161/ff57bb0f77354298dfdb2e2b311df7ac.png";s:5:"width";i:128;s:6:"height";i:198;}}';