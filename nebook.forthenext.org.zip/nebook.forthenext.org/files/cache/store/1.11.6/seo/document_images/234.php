<?php
if(!defined('__XE__')) { exit(); }
return 'a:1:{i:0;a:3:{s:8:"filepath";s:66:"./files/attach/images/146/234/e4e5b73a4ad6d440a98930d8c4f23979.jpg";s:5:"width";i:200;s:6:"height";i:129;}}';