<?php
if(!defined('__XE__')) { exit(); }
return 'a:1:{i:0;a:3:{s:8:"filepath";s:66:"./files/attach/images/146/153/58eba6c00114268de13821e559e84097.jpg";s:5:"width";i:351;s:6:"height";i:480;}}';