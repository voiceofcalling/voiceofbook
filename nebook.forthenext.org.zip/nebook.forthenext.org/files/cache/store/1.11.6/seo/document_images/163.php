<?php
if(!defined('__XE__')) { exit(); }
return 'a:1:{i:0;a:3:{s:8:"filepath";s:66:"./files/attach/images/131/163/5110515e54b1fde4c4783f8dddd58134.png";s:5:"width";i:128;s:6:"height";i:203;}}';