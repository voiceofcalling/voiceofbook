<?php
if(!defined('__XE__')) { exit(); }
return 'a:1:{i:0;a:3:{s:8:"filepath";s:66:"./files/attach/images/131/189/77b1bf1d633dc1c1023ec3d13d40823b.png";s:5:"width";i:128;s:6:"height";i:182;}}';