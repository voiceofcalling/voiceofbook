<?php
if(!defined('__XE__')) { exit(); }
return 'a:1:{i:0;a:3:{s:8:"filepath";s:66:"./files/attach/images/146/252/8f14ad0f2876c04af21afa9896c74cd4.png";s:5:"width";i:128;s:6:"height";i:194;}}';