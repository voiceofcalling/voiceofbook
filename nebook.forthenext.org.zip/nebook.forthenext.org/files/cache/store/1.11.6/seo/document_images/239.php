<?php
if(!defined('__XE__')) { exit(); }
return 'a:1:{i:0;a:3:{s:8:"filepath";s:66:"./files/attach/images/146/239/9e83b90eff743e19f1da74fcc1391e8a.png";s:5:"width";i:128;s:6:"height";i:155;}}';