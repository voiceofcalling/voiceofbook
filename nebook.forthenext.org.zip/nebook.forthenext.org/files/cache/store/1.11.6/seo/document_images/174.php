<?php
if(!defined('__XE__')) { exit(); }
return 'a:2:{i:0;a:3:{s:8:"filepath";s:66:"./files/attach/images/131/174/7dda5820bacc1f1091fee78b6bd0a387.png";s:5:"width";i:128;s:6:"height";i:193;}i:1;a:3:{s:8:"filepath";s:66:"./files/attach/images/131/174/8df1ba3c403e332917e6fa21274f0a16.png";s:5:"width";i:128;s:6:"height";i:193;}}';