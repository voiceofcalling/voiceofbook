<?php
if(!defined('__XE__')) { exit(); }
return 'a:1:{i:0;a:3:{s:8:"filepath";s:66:"./files/attach/images/131/149/2c94e1aa41b77ca1d2ce2bed5d61e0cd.png";s:5:"width";i:128;s:6:"height";i:188;}}';