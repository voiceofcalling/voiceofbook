<?php
if(!defined('__XE__')) { exit(); }
return 'a:1:{i:0;a:3:{s:8:"filepath";s:66:"./files/attach/images/146/176/55a009b944eb780168dd37f4b8e8dac1.jpg";s:5:"width";i:350;s:6:"height";i:465;}}';