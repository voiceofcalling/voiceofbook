<?php
if(!defined('__XE__')) { exit(); }
return 'a:1:{i:0;a:3:{s:8:"filepath";s:66:"./files/attach/images/146/241/0c62101049abcb649d5749a8025bab6a.png";s:5:"width";i:128;s:6:"height";i:162;}}';