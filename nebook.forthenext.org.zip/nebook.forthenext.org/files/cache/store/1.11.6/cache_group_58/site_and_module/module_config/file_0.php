<?php
if(!defined('__XE__')) { exit(); }
return 'O:8:"stdClass":3:{s:16:"allowed_filesize";s:1:"2";s:19:"allowed_attach_size";s:1:"2";s:17:"allowed_filetypes";s:3:"*.*";}';