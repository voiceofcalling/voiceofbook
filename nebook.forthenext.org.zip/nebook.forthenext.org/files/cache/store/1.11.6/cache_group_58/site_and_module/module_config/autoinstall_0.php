<?php
if(!defined('__XE__')) { exit(); }
return 'O:8:"stdClass":1:{s:14:"downloadServer";s:33:"http://download.xpressengine.com/";}';