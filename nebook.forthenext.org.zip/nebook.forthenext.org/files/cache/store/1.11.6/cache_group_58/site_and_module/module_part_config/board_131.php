<?php
if(!defined('__XE__')) { exit(); }
return 'a:6:{i:0;s:2:"no";i:1;s:5:"title";i:2;s:7:"regdate";i:3;s:12:"readed_count";i:4;s:9:"thumbnail";i:5;s:7:"summary";}';