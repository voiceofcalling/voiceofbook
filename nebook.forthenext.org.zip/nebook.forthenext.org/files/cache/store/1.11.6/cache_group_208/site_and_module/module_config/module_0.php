<?php
if(!defined('__XE__')) { exit(); }
return 'O:8:"stdClass":3:{s:18:"isUpdateFixedValue";b:1;s:10:"htmlFooter";N;s:9:"siteTitle";s:6:"neBook";}';