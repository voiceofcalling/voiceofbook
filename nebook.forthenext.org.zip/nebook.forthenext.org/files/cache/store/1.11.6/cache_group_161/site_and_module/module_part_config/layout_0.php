<?php
if(!defined('__XE__')) { exit(); }
return 'N;';