<?php
if(!defined('__XE__')) { exit(); }
return 'a:0:{}';