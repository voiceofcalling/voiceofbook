<?php
if(!defined('__XE__')) { exit(); }
return 'O:8:"stdClass":2:{s:9:"page_type";s:6:"WIDGET";s:7:"regdate";s:14:"20210709030632";}';