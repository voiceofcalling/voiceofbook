jQuery(document).ready(function(){
			jQuery('#xdtbanner').xdtslider({'delay':5000, 'fadeSpeed': 2000,'showNextPrev':true,'showPlayButton':true,'autoStart':true});
		});